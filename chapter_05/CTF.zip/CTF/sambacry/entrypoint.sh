#!/bin/bash

/usr/bin/supervisord &
/usr/local/samba/sbin/smbd -F -S -s /smb.conf --debuglevel=10 &


wait -n