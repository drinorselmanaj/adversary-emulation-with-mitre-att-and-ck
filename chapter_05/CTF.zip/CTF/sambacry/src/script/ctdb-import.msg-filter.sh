#!/bin/bash
#

set -e
set -u

cat -
echo ""
echo "(This used to be ctdb commit ${GIT_COMMIT})"

exit 0
