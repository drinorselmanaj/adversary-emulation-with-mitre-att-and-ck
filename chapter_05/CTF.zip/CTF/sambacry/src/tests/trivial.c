
void exit(int);

main()
{
	exit(0);
}
