#ifndef sambashell_h__
#define sambashell_h__
 
extern int samba_init_module(void);
 
#endif 
